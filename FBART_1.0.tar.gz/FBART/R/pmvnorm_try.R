pmvnorm_try = function(mu, sigma, lb, ub, B){
    tryCatch(
        expr = {
            pmvnorm(mu, sigma, lb, ub, B)
        },
        error = function(cond) {
            0
        },
        warning = function(cond) {
            0
        }
    )
}