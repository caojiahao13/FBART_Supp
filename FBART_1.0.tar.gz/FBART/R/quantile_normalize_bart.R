trank <- function(x) {
  x_unique <- unique(x)
  x_ranks <- rank(x_unique, ties.method = "max")
  tx <- x_ranks[match(x,x_unique)] - 1

  tx <- tx / length(unique(tx))
  tx <- tx / max(tx)

  return(tx)
}

#' Quantile normalization for predictors
#' 
#' Performs a quantile normalization to each column of the matrix \code{X}.
#'
#' @param X A design matrix, should not include a column for the intercept.
#'
#' @return A matrix \code{X_norm} such that each column gives the associated
#'   empirical quantile of each observation for each predictor.
#'
#' @examples
#' X <- matrix(rgamma(100 * 10, shape = 2), nrow = 100)
#' X <- quantile_normalize_bart(X)
#' summary(X)
#' 
quantile_normalize_bart <- function(X) {
  apply(X = X, MARGIN = 2, trank)
}
