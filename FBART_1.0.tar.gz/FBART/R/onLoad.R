.onLoad <- function(libname, pkgname) {
  library(TruncatedNormal)
  # Other initialization code...
}