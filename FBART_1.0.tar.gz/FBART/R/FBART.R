#' Create a list of hyperparameter values
#'
#'
#' @param X A matrix of training data covariates.
#' @param Y A list of vectors.
#' @param Phi_list a n vector of Phi matrices of shape m*J
#' @param Phi_list_test a (n_test) vector of Phi matrices of shape m*J
#' @param betas a n-by-J matrix for initial estimates of mu(xi)'s
#' @param is_constrained TRUE if constraints are involved.
#' @param D Constraint matrix.
#' @param lb lower bound for mvtnorm.
#' @param ub upper bound for mvtnorm.
#' @param num_tree Number of trees in the ensemble.
#'
#' @return Returns a list containing the function arguments.
Hypers <- function(X,Y, Phi_list, Phi_list_test, betas, 
                  is_constrained, D, lb, ub, B, alpha = 0.95, gamma = 0.25, num_tree = 100) {

  out                                  <- list()
  out$alpha                            <- alpha
  out$gamma                            <- gamma
  out$nu                               <- 3
  out$lambda                           <- var(unlist(Y))/out$nu*qchisq(0.1, df=out$nu)

  out$mu_mu                            <- (apply(betas, 2, max) + apply(betas, 2, min))/(2*num_tree)
  out$V_mu                             <- diag( (apply(betas, 2, max) - apply(betas, 2, min))^2/(16*num_tree) )
  out$V_mu_inv                         <- solve(out$V_mu)

  out$num_tree                         <- num_tree

  out$p                                <- dim(X)[2] 
  out$m_list                           <- sapply(Y, FUN = function(x){return(length(x))})
  out$J                                <- dim(betas)[2] 

  out$Phi_list                         <- Phi_list
  out$Phi_list_test                    <- Phi_list_test
  out$D                                <- D
  out$D_inv                            <- solve(D)
  out$is_constrained                   <- is_constrained
  if(out$is_constrained){
    out$lb = lb
    out$ub = ub
    out$prior_trunc_prob = rcpp_pmvnorm( (out$D)%*%(out$mu_mu), (out$D)%*%(out$V_mu)%*%t(out$D), 
                                        out$lb, out$ub, B*10);
  }else{
    out$lb = rep(-Inf, nrow(D))
    out$ub = rep(Inf, nrow(D))
    out$prior_trunc_prob = 1.0
  }
  out$B                                <- B

  out$sigma                            <- out$lambda
  out$sigma_hat                        <- out$lambda

  return(out)
}

#' MCMC options for FBart
#'
#' Creates a list that provides the parameters for running the Markov chain.
#'
#' @param num_burn Number of warmup iterations for the chain.
#' @param num_thin Thinning interval for the chain.
#' @param num_save The number of samples to collect; in total, \code{num_burn + num_save * num_thin} iterations are run.
#' @param num_print Interval for how often to print the chain's progress.
#'
#' @return Returns a list containing the function arguments.
Opts <- function(num_burn = 2500, num_thin = 1, num_save = 2500, num_print = 100) {
  out <- list()
  out$num_burn        <- num_burn
  out$num_thin        <- num_thin
  out$num_save        <- num_save
  out$num_print       <- num_print

  return(out)

}

#' Fits the FBART model
#'
#' Runs the Markov chain for FOSR
#'
#' @param X A matrix of training data covariates.
#' @param Y A list of response vectors.
#' @param X_test A matrix of test data covariates.
#' @param Phi_list a n vector of Phi matrices of shape m*J
#' @param Phi_list_test a (n_test) vector of Phi matrices of shape m*J
#' @param betas a n-by-J matrix for initial estimates of mu(xi)'s
#' @param is_constrained TRUE if constraints are involved.
#' @param D Constraint matrix.
#' @param lb lower bound for mvtnorm.
#' @param ub upper bound for mvtnorm.
#' @param B number of samples for calculating normal probabilities.
#' @param alpha probability of a trivial tree.
#' @param gamma penalizing depth tree.
#' @param num_tree Number of trees in the ensemble.
#'
#' @return Returns a list with the following components:
#' \itemize{
#'   \item \code{y_hat_train}: predicted values for the training data for each iteration of the chain.
#'   \item \code{y_hat_test}: predicted values for the test data for each iteration of the chain.
#'   \item \code{sigma}: posterior samples of the error standard deviations.
#' }
#' 
#' 
fit_FBART <- function(X, Y, X_test, Phi_list, Phi_list_test, betas, is_constrained, D, lb, ub, B = 1000, 
                alpha = 0.95, gamma = 0.25,
                num_tree = 50, num_burn = 2500, num_thin = 1, num_save = 2500, num_print = 100,
                  hypers = NULL, opts = NULL, verbose = TRUE, do_var_trans = TRUE) {

  if(is.null(hypers)){
    hypers <- Hypers(X,Y,Phi_list, Phi_list_test, betas, is_constrained, D, lb, ub, B = B, alpha = alpha, gamma = gamma, num_tree = num_tree)
  }
  if(is.null(opts)){
    opts <- Opts(num_burn, num_thin, num_save, num_print)
  }

  ## Quantile normalize X
  n <- nrow(X)
  idx_train <- 1:n
  X_trans <- rbind(X, X_test)

  if(!verbose) {
    opts$num_print <- .Machine$integer.max
  }

  
  if(length(do_var_trans) == 1) {X_trans <- quantile_normalize_bart(X_trans)}
  if(length(do_var_trans) > 1) {
    ids_var = which(do_var_trans)
    for(i_id in ids_var){
      X_trans[,i_id] = trank(X_trans[,i_id])
    }
  }


  X <- X_trans[idx_train,,drop=FALSE]
  X_test <- X_trans[-idx_train,,drop=FALSE]

  print('Start FBART')
  fit <- Do_Functional_Bart(X,Y,X_test,
                hypers$alpha, hypers$gamma, hypers$lambda, hypers$nu, 
                hypers$mu_mu, hypers$V_mu, hypers$V_mu_inv, 
                hypers$num_tree, hypers$p, hypers$m_list, hypers$J, 
                hypers$Phi_list, hypers$Phi_list_test, 
                hypers$D, hypers$D_inv, 
                hypers$is_constrained, hypers$lb, hypers$ub, hypers$prior_trunc_prob, hypers$B,
                hypers$sigma, hypers$sigma_hat,
                opts$num_burn, opts$num_thin, opts$num_save, opts$num_print)

  class(fit) <- "fbart"

  return(fit)

}