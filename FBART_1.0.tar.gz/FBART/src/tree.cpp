#include "tree.h"
#include <RcppArmadillo.h>

using namespace Rcpp;
using namespace arma;

// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Hyperparameters

Hypers::Hypers() {
  alpha = 0.95;
  gamma = 2.0;
}

// Hypers::Hypers(Rcpp::List hypers) {
//   alpha = hypers["alpha"];
//   gamma = hypers["gamma"];
//   lambda = hypers["lambda"];
//   nu = hypers["nu"];
//   mu_mu = castNumericVectorToArmaVec(hypers["mu_mu"]);
//   V_mu = castNumericMatrixToArmaMat(hypers["V_mu"]);
//   // V_mu_inv = arma::inv_sympd( (V_mu + trans(V_mu))/2.0 );
//   V_mu_inv = arma::inv_sympd( V_mu );
//   num_tree = hypers["num_tree"];

//   p = hypers["p"];
//   m = hypers["m"];
//   J = hypers["J"];
//   Rcpp::List R_Phi_list = hypers["Phi_list"];
//   for(int i = 0 ; i< R_Phi_list.length(); i++){
//     Phi_list[i] = castNumericMatrixToArmaMat(R_Phi_list[i]);
//   }
//   Rcpp::List R_Phi_list_test = hypers["Phi_list_test"];
//   for(int i = 0 ; i< R_Phi_list_test.length(); i++){
//     Phi_list_test[i] = castNumericMatrixToArmaMat(R_Phi_list_test[i]);
//   }

//   D = castNumericMatrixToArmaMat(hypers["D"]);
//   D_inv = arma::inv(D);

//   is_constrained = hypers["is_constrained"];
//   if(is_constrained){
//     arma::vec lb(D.n_rows, fill::zeros);
//     arma::vec ub = arma::vec(D.n_rows);
//     ub.fill(R_PosInf);
//     prior_trunc_prob = exp(      
//       rcpp_lpmvnorm(mu_mu, V_mu, lb, ub)
//       );
//   }else{
//     prior_trunc_prob = 1.0;
//   }

//   sigma = hypers["sigma"];
//   sigma_hat = hypers["sigma_hat"];
// }

Opts InitOpts(int num_burn, int num_thin, int num_save, int num_print){
  Opts out;
  out.num_burn = num_burn;
  out.num_thin = num_thin;
  out.num_save = num_save;
  out.num_print = num_print;

  return out;
}

// Process hyperparameters from R.
Hypers InitHypers(double alpha, double gamma, double lambda, double nu, 
              arma::vec mu_mu, arma::mat V_mu, arma::mat V_mu_inv,
              int num_tree, int p, Rcpp::IntegerVector m_list, int J,
              Rcpp::List R_Phi_list, Rcpp::List R_Phi_list_test,
              arma::mat D, arma::mat D_inv, 
              bool is_constrained, arma::vec lb, arma::vec ub, double prior_trunc_prob, int B,
              double sigma, double sigma_hat){
  Hypers out;
  out.alpha = alpha;
  out.gamma = gamma;
  out.lambda = lambda;
  out.nu = nu;
  out.mu_mu = mu_mu;
  out.V_mu = (V_mu + trans(V_mu))/2;   // Force to be symmetric
  out.V_mu_inv = (V_mu_inv + trans(V_mu_inv))/2;   // Force to be symmetric
  out.num_tree = num_tree;
  out.p = p;
  arma::uvec C_m_list(m_list.size(), fill::zeros);
  for(uword i = 0; i<m_list.size(); i++){
      C_m_list(i) = m_list[i];
  }  
  out.m_list = C_m_list;
  out.J = J;
  // out.Phi_list = Phi_list;
  // out.Phi_list_test = Phi_list_test;
  std::vector<arma::mat> C_Phi_list(R_Phi_list.length());
  std::vector<arma::mat> C_Phi_list_test(R_Phi_list_test.length());
  for(int i = 0 ; i< R_Phi_list.length(); i++){
    C_Phi_list[i] = castNumericMatrixToArmaMat(R_Phi_list[i]);
  }
  for(int i = 0 ; i< R_Phi_list_test.length(); i++){
    C_Phi_list_test[i] = castNumericMatrixToArmaMat(R_Phi_list_test[i]);
  }
  out.Phi_list = C_Phi_list;
  out.Phi_list_test = C_Phi_list_test;

  out.D = D;
  out.D_inv = D_inv;
  out.is_constrained = is_constrained;
  out.lb = lb;
  out.ub = ub;
  out.prior_trunc_prob = prior_trunc_prob;
  out.B = B;
  out.sigma = sigma;
  out.sigma_hat = sigma_hat;

  return out;
}


double update_sigma(const std::vector<arma::vec>& R, double lambda, double nu, arma::uvec m_list) {

  double SSE = 0; //arma::accu(R % R);
  for(int i = 0 ; i< R.size(); i++){
      SSE += arma::accu(R[i] % R[i]);
  }
  int Nn = arma::accu(m_list);

  double shape = 0.5 * Nn + 0.5 * nu;
  double scale = 1 / (0.5 * lambda * nu + 0.5 * SSE );
  double sigma_new = arma::randg( distr_param(shape,scale) );
  sigma_new = sqrt(1/sigma_new);
  return sigma_new;
}

int Hypers::SampleVar() const {
  return sample_class(p);
}
void Hypers::UpdateSigma(const std::vector<arma::vec>& R) {
  sigma = update_sigma(R, lambda, nu, m_list);
}
// =====================// =====================// =====================// =====================
// =====================// =====================// =====================// =====================
// Tree utilites

//-----------------//-----------------//-----------------
// basic
int depth(Node* node) {
  return node->is_root ? 0 : 1 + depth(node->parent);
}
bool Node::is_left() {
  return (this == this->parent->left);
}
bool is_left(Node* n) {
  return n->is_left();
}

//-----------------//-----------------//-----------------
// Initializing tools

Node::Node() {
  is_leaf = true;
  is_root = true;
  left = NULL;
  right = NULL;
  parent = NULL;

  var = 0;
  val = 0.0;
  lower = 0.0;
  upper = 1.0;
  // mu = 0.0;
  current_weight = 0.0;
}

Node::~Node() {
  if(!is_leaf) {
    delete left;
    delete right;
  }
}

void Node::Root(const Hypers& hypers) {
  is_leaf = true;
  is_root = true;
  left = this;
  right = this;
  parent = this;

  var = 0;
  val = 0.0;
  lower = 0.0;
  upper = 1.0;

  mu = arma::zeros(hypers.J);
  current_weight = 1.0;
}
std::vector<Node*> init_forest(const Hypers& hypers) {
  std::vector<Node*> forest(0);
  for(int t = 0; t < hypers.num_tree; t++) {
    Node* n = new Node;
    n->Root(hypers);
    forest.push_back(n);
  }
  return forest;
}


//-----------------//-----------------//-----------------
// Leaves and braches

// Collect the leaves
void leaves(Node* x, std::vector<Node*>& leafs) {
  if(x->is_leaf) {
    leafs.push_back(x);
  }
  else {
    leaves(x->left, leafs);
    leaves(x->right, leafs);
  }
}
std::vector<Node*> leaves(Node* x) {
  std::vector<Node*> leafs(0);
  leaves(x, leafs);
  return leafs;
}

// Collect the branches
void branches(Node* n, std::vector<Node*>& branch_vec) {
  if(!(n->is_leaf)) {
    branch_vec.push_back(n);
    branches(n->left, branch_vec);
    branches(n->right, branch_vec);
  }
}
std::vector<Node*> branches(Node* root) {
  std::vector<Node*> branch_vec;
  branch_vec.resize(0);
  branches(root, branch_vec);
  return branch_vec;
}

// Collect the non-grand branches
std::vector<Node*> not_grand_branches(Node* tree) {
  std::vector<Node*> ngb(0);
  not_grand_branches(ngb, tree);
  return ngb;
}
void not_grand_branches(std::vector<Node*>& ngb, Node* node) {
  if(!node->is_leaf) {
    bool left_is_leaf = node->left->is_leaf;
    bool right_is_leaf = node->right->is_leaf;
    if(left_is_leaf && right_is_leaf) {
      ngb.push_back(node);
    }
    else {
      not_grand_branches(ngb, node->left);
      not_grand_branches(ngb, node->right);
    }
  }
}

Node* death_node(Node* tree, double* p_not_grand) {
  std::vector<Node*> ngb = not_grand_branches(tree);
  Node* branch = rand(ngb);
  *p_not_grand = 1.0 / ((double)ngb.size());

  return branch;
}
//-----------------//-----------------//-----------------
// Covariate allocation

double activation(double x, double c) {
  return x>c ? 0.0: 1.0;
}

// Get the weights of the mu's, which is calculated up-down in SBART, for the i-th covariate.
// In BART, this is equivalent to find the corresponding leaf.
void Node::GetW(const arma::mat& X, int i) {

  if(!is_leaf) {

    double weight = activation(X(i,var), val);
    left->current_weight = weight * current_weight;
    right->current_weight = (1 - weight) * current_weight;

    left->GetW(X,i);
    right->GetW(X,i);

  }
}

// ----------------// ----------------// ----------------
// utilities for cutpoints
void Node::GetLimits() {
  Node* y = this;
  lower = 0.0;
  upper = 1.0;
  bool my_bool = y->is_root ? false : true;
  while(my_bool) {
    bool is_left = y->is_left();
    y = y->parent;
    my_bool = y->is_root ? false : true;
    if(y->var == var) {
      my_bool = false;
      if(is_left) {
        upper = y->val;
        lower = y->lower;
      }
      else {
        upper = y->upper;
        lower = y->val;
      }
    }
  }
}

double calc_cutpoint_likelihood(Node* node) {
  if(node->is_leaf) return 1;
  
  double out = 1.0/(node->upper - node->lower);
  out = out * calc_cutpoint_likelihood(node->left);
  out = out * calc_cutpoint_likelihood(node->right);
  
  return out;
}
std::vector<double> get_perturb_limits(Node* branch) {
  double min = 0.0;
  double max = 1.0;
  
  Node* n = branch;
  while(!(n->is_root)) {
    if(n->is_left()) {
      n = n->parent;
      if(n->var == branch->var) {
        if(n->val > min) {
          min = n->val;
        }
      }
    }
    else {
      n = n->parent;
      if(n->var == branch->var) {
        if(n->val < max) {
          max = n->val;
        }
      }
    }
  }
  std::vector<Node*> left_branches = branches(n->left);
  std::vector<Node*> right_branches = branches(n->right);
  for(int i = 0; i < left_branches.size(); i++) {
    if(left_branches[i]->var == branch->var) {
      if(left_branches[i]->val > min)
        min = left_branches[i]->val;
    }
  }
  for(int i = 0; i < right_branches.size(); i++) {
    if(right_branches[i]->var == branch->var) {
      if(right_branches[i]->val < max) {
        max = right_branches[i]->val;
      }
    }
  }
  
  std::vector<double> out; out.push_back(min); out.push_back(max);
  return out;
}

void get_limits_below(Node* node) {
  node->GetLimits();
  if(!(node->left->is_leaf)) {
    get_limits_below(node->left);
  }
  if(!(node->right->is_leaf)) {
    get_limits_below(node->right);
  }
}

// ------------// ------------// ------------
// Tree evaluation

std::vector<arma::vec> predict(Node* n, const arma::mat& X, const Hypers& hypers) {

  std::vector<Node*> leafs = leaves(n);
  int num_leaves = leafs.size();
  int N = X.n_rows;
  std::vector<arma::vec> out(N);
  for(int i = 0; i < N; i++) {
    n->GetW(X,i);
    for(int j = 0; j < num_leaves; j++) {
      if( (leafs[j]->current_weight)== 1.0 ){
        // Find the leaf, and calculate the value
        out[i] = (hypers.Phi_list[i]) * (leafs[j]->mu);
        break;
      }
    }
  }

  return out;

}
std::vector<arma::vec> predict(const std::vector<Node*>& forest,
                  const arma::mat& X,
                  const Hypers& hypers) {

  std::vector<arma::vec> out = predict(forest[0], X, hypers);
  int num_tree = forest.size();

  for(int t = 1; t < num_tree; t++) {
      out = out + predict(forest[t], X, hypers);
  }

  return out;
}


std::vector<arma::vec> predict_test(Node* n, const arma::mat& X, const Hypers& hypers) {

  std::vector<Node*> leafs = leaves(n);
  int num_leaves = leafs.size();
  int N = X.n_rows;
  std::vector<arma::vec> out(N);

  for(int i = 0; i < N; i++) {
    n->GetW(X,i);
    for(int j = 0; j < num_leaves; j++) {
      if( (leafs[j]->current_weight)== 1.0 ){
        // Find the leaf, and calculate the value
        out[i] = (hypers.Phi_list_test[i]) * (leafs[j]->mu);
        break;
      }
    }
  }

  return out;

}
std::vector<arma::vec> predict_test(const std::vector<Node*>& forest,
                  const arma::mat& X,
                  const Hypers& hypers) {

  int N = X.n_rows;
  std::vector<arma::vec> out = predict_test(forest[0], X, hypers);
  int num_tree = forest.size();

  for(int t = 1; t < num_tree; t++) {
      out = out + predict_test(forest[t], X, hypers);
  }

  return out;
}

// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Tree STAT
/*Computes the sufficient statistics Omega_inv and mu_hat described in the
  paper; mu_hat is the posterior mean of the leaf nodes, Omega_inv is that
  posterior covariance*/

// CovAssign: i-th covariate is in leaf j
void GetSuffStats(Node* n, const std::vector<arma::vec>& R, const arma::mat& X, const Hypers& hypers,
                  std::vector<arma::vec>& mu_hat_vec, 
                  std::vector<arma::mat>& Omega_vec, std::vector<arma::mat>& Omega_inv_vec,
                  arma::uvec& CovAssign) {

  std::vector<Node*> leafs = leaves(n);
  uword num_leaves = leafs.size();
  vec mu_hat = solve(hypers.V_mu, hypers.mu_mu);
  mat Omega_inv = hypers.V_mu_inv;
  for(uword j = 0; j < num_leaves; j++){
    mu_hat_vec[j] = mu_hat;
    Omega_inv_vec[j] = Omega_inv;
  }
  
  for(uword i = 0; i < X.n_rows; i++) {
    n->GetW(X, i);
    for(uword j = 0; j < num_leaves; j++) {
      if((leafs[j]->current_weight) == 1.0){
        mu_hat_vec[j] = mu_hat_vec[j] + ( trans(hypers.Phi_list[i]) * (R[i]) ) / pow(hypers.sigma, 2);
        Omega_inv_vec[j] = Omega_inv_vec[j] + ( trans(hypers.Phi_list[i]) * (hypers.Phi_list[i]) ) / pow(hypers.sigma, 2);
        // Omega_vec[j] = inv_sympd(Omega_inv_vec[j]);
        CovAssign[i] = j;
        break;
      }
    }
  }

  for(uword j = 0; j < num_leaves; j++){
    Omega_inv_vec[j] = (Omega_inv_vec[j] + trans(Omega_inv_vec[j]))/2;
    Omega_vec[j] = inv_sympd(Omega_inv_vec[j]);
    mu_hat_vec[j] = Omega_vec[j] * mu_hat_vec[j];
  }
}

double LogLT(Node* n, const std::vector<arma::vec>& R, const arma::mat& X, const Hypers& hypers) {
  // Rcout << "Leaves ";
  std::vector<Node*> leafs = leaves(n);
  uword num_leaves = leafs.size();

  // Get sufficient statistics
  std::vector<arma::vec> mu_hat_vec(num_leaves, arma::zeros<arma::vec>(hypers.J));
  std::vector<arma::mat> Omega_vec(num_leaves, arma::zeros<arma::mat>(hypers.J,hypers.J));
  std::vector<arma::mat> Omega_inv_vec(num_leaves, arma::zeros<arma::mat>(hypers.J,hypers.J));
  arma::uvec CovAssign(R.size());
  GetSuffStats(n, R, X, hypers, mu_hat_vec, Omega_vec, Omega_inv_vec, CovAssign);
  arma::uvec id_in_leaf;

  // Rcout << "Compute ";
  double out = 0;
  for(uword j = 0; j < num_leaves; j++) {
    id_in_leaf = find(CovAssign == j);
    out += -0.5 * arma::accu( (hypers.m_list).elem(id_in_leaf) ) * log(M_2PI * pow(hypers.sigma,2));

    out += -0.5 * arma::log_det_sympd( hypers.V_mu );
    out -= -0.5 * arma::log_det_sympd( Omega_vec[j] );

    out += 0.5 * dot( mu_hat_vec[j], (Omega_inv_vec[j]) * (mu_hat_vec[j]) );
    for(uword i = 0 ; i< id_in_leaf.n_elem; i++){
      out += -0.5 / pow(hypers.sigma,2) * arma::accu(R[id_in_leaf(i)] % R[id_in_leaf(i)]);
    }
    out += -0.5 * dot( hypers.mu_mu, hypers.V_mu_inv * hypers.mu_mu );
  }

  if(hypers.is_constrained){
    arma::vec mu_eta = mu_hat_vec[0];
    arma::mat V_eta = Omega_vec[0];    

    double posterior_trunc_prob = 0;
    for(uword j = 0; j < num_leaves; j++) {
      mu_eta = ( hypers.D )*( mu_hat_vec[j] );
      V_eta = ( hypers.D )*( Omega_vec[j] ) * trans( hypers.D );
      posterior_trunc_prob = rcpp_pmvnorm(mu_eta, V_eta, hypers.lb, hypers.ub, hypers.B);
      // Rcpp::Rcout<<posterior_trunc_prob<<std::endl;
      // If trunc prob is zero, then set out to be -INF.
      if(posterior_trunc_prob == 0){
        // Rcpp::Rcout<<"Normal Prob in Constraint is Zero"<<std::endl;
        out = -std::numeric_limits<double>::infinity();
        break;
      }else{
        out += log(posterior_trunc_prob) - log(hypers.prior_trunc_prob);
      }

    }
  }

  // Rcout << "Done";
  return out;
}


// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Tree random samplers
Node* rand(std::vector<Node*> ngb) {

  int N = ngb.size();
  arma::vec p = ones<vec>(N) / ((double)(N));
  int i = sample_class(p);
  return ngb[i];
}

Node* birth_node(Node* tree, double* leaf_node_probability) {
  std::vector<Node*> leafs = leaves(tree);
  Node* leaf = rand(leafs);
  *leaf_node_probability = 1.0 / ((double)leafs.size());

  return leaf;
}

// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Tree modifications

double SplitProb(Node* node, const Hypers& hypers) {
  double d = (double)(depth(node));
  return hypers.alpha * pow(hypers.gamma, d);
}

void Node::AddLeaves() {
  left = new Node;
  right = new Node;
  is_leaf = false;

  // Initialize the leaves

  left->is_leaf = true;
  left->parent = this;
  left->right = left;
  left->left = left;
  left->var = 0;
  left->val = 0.0;
  left->is_root = false;
  left->lower = 0.0;
  left->upper = 1.0;
  left->mu = arma::vec();
  left->current_weight = 0.0;
  right->is_leaf = true;
  right->parent = this;
  right->right = right;
  right->left = right;
  right->var = 0;
  right->val = 0.0;
  right->is_root = false;
  right->lower = 0.0;
  right->upper = 1.0;
  right->mu = arma::vec();
  right->current_weight = 0.0;

}

// -----------// -----------// -----------// -----------// -----------
// Sampling mu from posterior
void Node::UpdateMu(const std::vector<arma::vec>& R, const arma::mat& X, const Hypers& hypers) {

  std::vector<Node*> leafs = leaves(this);
  int num_leaves = leafs.size();

  // Get mean and covariance
  std::vector<arma::vec> mu_hat_vec(num_leaves, arma::zeros<arma::vec>(hypers.J));
  std::vector<arma::mat> Omega_vec(num_leaves, arma::zeros<arma::mat>(hypers.J,hypers.J));
  std::vector<arma::mat> Omega_inv_vec(num_leaves, arma::zeros<arma::mat>(hypers.J,hypers.J));
  arma::uvec CovAssign(R.size());
  GetSuffStats(this, R, X, hypers, mu_hat_vec, Omega_vec, Omega_inv_vec, CovAssign);


  if(hypers.is_constrained){
    arma::vec mu_eta = mu_hat_vec[0];
    arma::mat V_eta = Omega_vec[0];
    for(int j = 0; j < num_leaves; j++) {
      mu_eta = ( hypers.D )*( mu_hat_vec[j] );
      V_eta = ( hypers.D )*( Omega_vec[j] ) * trans( hypers.D );
      leafs[j]->mu = ( hypers.D_inv ) * rcpp_rtmvnorm(mu_eta, V_eta, hypers.lb, hypers.ub);
    }
  }else{
    for(int j = 0; j < num_leaves; j++) {
      leafs[j]->mu = rmvnorm(mu_hat_vec[j], Omega_inv_vec[j]);
    }
  }
}

// -----------// -----------// -----------// -----------// -----------
// Growth (with prior sampling) and prune
void Node::BirthLeaves(const Hypers& hypers) {
  if(is_leaf) {
    AddLeaves();
    var = hypers.SampleVar();
    GetLimits();
    val = (upper - lower) * unif_rand() + lower;
  }
}

void Node::GenBelow(const Hypers& hypers) {
  double grow_prob = SplitProb(this, hypers);
  double u = unif_rand();
  if(u < grow_prob) {
    BirthLeaves(hypers);
    left->GenBelow(hypers);
    right->GenBelow(hypers);
  }
}
void Node::GenTree(const Hypers& hypers) {
  Root(hypers);
  GenBelow(hypers);
}

void Node::DeleteLeaves() {
  delete left;
  delete right;
  left = this;
  right = this;
  is_leaf = true;
}
