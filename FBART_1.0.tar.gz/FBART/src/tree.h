#ifndef TREE_H
#define TREE_H

#include "statfunc.h"
#include <RcppArmadillo.h>


// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Hyperparameters
struct Hypers;
struct Node;

struct Hypers {

  double alpha;  //p_split(d) = alpha gamma^d 
  double gamma;
  double lambda;  // \sigma^2 ~ nu lambda / Chi^2_nu
  double nu;
  arma::vec mu_mu; // prior of mu
  arma::mat V_mu;
  arma::mat V_mu_inv;
  int num_tree;
  
  int p;
  arma::uvec m_list;
  int J;

  std::vector<arma::mat> Phi_list; // a (n) vector of Phi matrices of shape m*J
  std::vector<arma::mat> Phi_list_test; // a (n_test) vector of Phi matrices of shape m*J
  arma::mat D; // constraint matrix
  arma::mat D_inv; // inversion of the constraint matrix
  bool is_constrained; 
  // arma::vec lb( (hypers.D).n_rows, fill::zeros);
  // arma::vec ub = arma::vec( (hypers.D).n_rows);
  arma::vec lb;
  arma::vec ub;
  double prior_trunc_prob;
  int B;

  double sigma; // current noise sd parameter
  double sigma_hat; // initial sd parameter

  void UpdateSigma(const std::vector<arma::vec>& R); // update parameter sigma

  int SampleVar() const;
  // Hypers(Rcpp::List hypers);
  Hypers();

};

struct Opts {
  int num_burn;
  int num_thin;
  int num_save;
  int num_print;

Opts(){
  num_burn = 1;
  num_thin = 1;
  num_save = 1;
  num_print = 100;
}

Opts(Rcpp::List opts_) {
  num_burn = opts_["num_burn"];
  num_thin = opts_["num_thin"];
  num_save = opts_["num_save"];
  num_print = opts_["num_print"];
}

};


Opts InitOpts(int num_burn, int num_thin, int num_save, int num_print);
Hypers InitHypers(double alpha, double gamma, double lambda, double nu, 
              arma::vec mu_mu, arma::mat V_mu, arma::mat V_mu_inv,
              int num_tree, int p, Rcpp::IntegerVector, int J,
              Rcpp::List R_Phi_list, Rcpp::List R_Phi_list_test,
              arma::mat D, arma::mat D_inv, 
              bool is_constrained, arma::vec lb, arma::vec ub, double prior_trunc_prob, int B,
              double sigma, double sigma_hat);
// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Data structures for tree, i.e., Node. 
struct Node {

  bool is_leaf;
  bool is_root;
  Node* left;
  Node* right;
  Node* parent;

  // Branch parameters
  int var;
  double val;
  double lower;
  double upper;

  // Leaf parameters
  arma::vec mu;

  // Data for computing weights
  // current_weight is 0 or 1 in BART.
  double current_weight;

  // Functions
  void Root(const Hypers& hypers);
  void GetLimits(); // Look above and set the limits of the current node
  void AddLeaves();
  void BirthLeaves(const Hypers& hypers);
  bool is_left();
  void GenTree(const Hypers& hypers);
  void GenBelow(const Hypers& hypers);
  void GetW(const arma::mat& X, int i);
  void DeleteLeaves();
  void UpdateMu(const std::vector<arma::vec>& R, const arma::mat& X, const Hypers& hypers);

  Node();
  ~Node();

};


std::vector<Node*> init_forest(const Hypers& hypers);
double activation(double x, double c);
// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Utilities for trees and forests

//-----------------//-----------------//-----------------
// Leaves and braches
// Collect the leaves
void leaves(Node* x, std::vector<Node*>& leafs);
std::vector<Node*> leaves(Node* x);
// Collect the braches
void branches(Node* n, std::vector<Node*>& branch_vec);
std::vector<Node*> branches(Node* root);
// Collect the non-grand branches
std::vector<Node*> not_grand_branches(Node* tree);
void not_grand_branches(std::vector<Node*>& ngb, Node* node);
Node* death_node(Node* tree, double* p_not_grand);
// Get depth
int depth(Node* node);
// tree prediction 
std::vector<arma::vec> predict(Node* node,
                  const arma::mat& X,
                  const Hypers& hypers);
// forest prediction
std::vector<arma::vec> predict(const std::vector<Node*>& forest,
                  const arma::mat& X,
                  const Hypers& hypers);

// prediction for test data (i.e., using hypers.Phi_list_test)
std::vector<arma::vec> predict_test(Node* node,
                  const arma::mat& X,
                  const Hypers& hypers);
std::vector<arma::vec> predict_test(const std::vector<Node*>& forest,
                  const arma::mat& X,
                  const Hypers& hypers);


// ----------------// ----------------// ----------------
// utilities for cutpoints
double calc_cutpoint_likelihood(Node* node);
std::vector<double> get_perturb_limits(Node* branch);
void get_limits_below(Node* node);
// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Others
double SplitProb(Node* node, const Hypers& hypers);

// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Tree random samplers
Node* rand(std::vector<Node*> ngb);
Node* birth_node(Node* tree, double* leaf_node_probability);
// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Tree STAT
void GetSuffStats(Node* n, const std::vector<arma::vec>& R, const arma::mat& X, const Hypers& hypers,
                  std::vector<arma::vec>& mu_hat_vec, 
                  std::vector<arma::mat>& Omega_vec, std::vector<arma::mat>& Omega_inv_vec,
                  arma::uvec& CovAssign);

double LogLT(Node* n, const std::vector<arma::vec>& R, const arma::mat& X, const Hypers& hypers);

#endif
