#ifndef STATFUNC_H
#define STATFUNC_H

#include <RcppArmadillo.h>

// ----------
// Tools
arma::vec castNumericVectorToArmaVec(Rcpp::NumericVector x);
arma::mat castNumericMatrixToArmaMat(Rcpp::NumericMatrix x);
// Reload + and - for  std::vector<arma::vec>
template <typename T>
std::vector<arma::Col<T>> operator+(const std::vector<arma::Col<T>>& a, const std::vector<arma::Col<T>>& b) {
    if (a.size() != b.size()) {
        throw std::invalid_argument("Vectors have different sizes");
    }

    std::vector<arma::Col<T>> result(a.size());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] + b[i];
    }

    return result;
}

template <typename T>
std::vector<arma::Col<T>> operator-(const std::vector<arma::Col<T>>& a, const std::vector<arma::Col<T>>& b) {
    if (a.size() != b.size()) {
        throw std::invalid_argument("Vectors have different sizes");
    }

    std::vector<arma::Col<T>> result(a.size());
    for (size_t i = 0; i < a.size(); ++i) {
        result[i] = a[i] - b[i];
    }

    return result;
}


int sample_class(const arma::vec& probs);
int sample_class(int n);

arma::vec rmvnorm(const arma::vec& mean, const arma::mat& Precision);

double log_sum_exp(const arma::vec& x);

// TruncatedNormal: https://github.com/lbelzile/TruncatedNormal/blob/249e0f62e045c2e1936c74620f981542f7dc6385/R/tmvnorm.R
//  rtmvnorm(n, mu, sigma, lb, ub)}
//  ptmvnorm(q, mu, sigma, lb, ub, type = c("mc", "qmc"), log = FALSE, B = 1e4)
arma::vec rcpp_rtmvnorm(const arma::vec mu, const arma::mat sigma, 
                            const arma::vec lb, const arma::vec ub);
double rcpp_pmvnorm(const arma::vec mu, const arma::mat sigma, 
                            const arma::vec lb, const arma::vec ub, int B);


#endif
