#include <RcppArmadillo.h>
#include "statfunc.h"


arma::vec castNumericVectorToArmaVec(Rcpp::NumericVector x) {
  arma::vec y = arma::vec(x.begin(), x.size(), true);
  return y;
}
arma::mat castNumericMatrixToArmaMat(Rcpp::NumericMatrix x) {
  arma::mat y = arma::mat(x.begin(), x.nrow(), x.ncol(), true);
  return y;
}

// ------------------// ------------------// ------------------// ------------------
// statfunctions
int sample_class(const arma::vec& probs) {
  double U = R::unif_rand();
  double foo = 0.0;
  int K = probs.size();

  // Sample
  for(int k = 0; k < K; k++) {
    foo += probs(k);
    if(U < foo) {
      return(k);
    }
  }
  return K - 1;
}

int sample_class(int n) {
  double U = R::unif_rand();
  double p = 1.0 / ((double)n);
  double foo = 0.0;

  for(int k = 0; k < n; k++) {
    foo += p;
    if(U < foo) {
      return k;
    }
  }
  return n - 1;
}

// [[Rcpp::export]]
arma::vec rmvnorm(const arma::vec& mean, const arma::mat& Precision) {
  arma::vec z = arma::zeros<arma::vec>(mean.size());
  for(arma::uword i = 0; i < mean.size(); i++) {
    z(i) = norm_rand();
  }
  arma::mat Sigma = inv_sympd(Precision);
  arma::mat L = chol(Sigma, "lower");
  arma::vec h = mean + L * z;
  /* arma::mat R = chol(Precision); */
  /* arma::vec h = solve(R,z) + mean; */
  return h;
}

// [[Rcpp::export]]
arma::mat choll(const arma::mat& Sigma) {
  return chol(Sigma);
}

double log_sum_exp(const arma::vec& x) {
  double M = x.max();
  return M + log(sum(exp(x - M)));
}

// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// TruncatedNormal: https://github.com/lbelzile/TruncatedNormal/blob/249e0f62e045c2e1936c74620f981542f7dc6385/R/tmvnorm.R
//  rtmvnorm(n, mu, sigma, lb, ub)}
//  ptmvnorm(q, mu, sigma, lb, ub, type = c("mc", "qmc"), log = FALSE, B = 1e4)
// , bool use_constraint = false


// // [[Rcpp::export]]
// Rcpp::NumericMatrix rcpp_rtmvnorm(int n, const Rcpp::NumericVector mu, const Rcpp::NumericMatrix sigma, 
//                             const Rcpp::NumericVector lb, const Rcpp::NumericVector ub){    
//     // calling rtmvnorm()
//     Rcpp::Function f("rtmvnorm");   

//     // Next code is interpreted as rnorm(n=5, mean=10, sd=2)
//     Rcpp::NumericMatrix res = f(n, Rcpp::_["mu"]=mu, Rcpp::_["sigma"]=sigma, Rcpp::_["lb"]=lb, Rcpp::_["ub"]=ub);
                            
//     return res;
// }
// [[Rcpp::export]]
arma::vec rcpp_rtmvnorm(const arma::vec mu, const arma::mat sigma, 
                            const arma::vec lb, const arma::vec ub){    
    // calling rtmvnorm()
    Rcpp::Environment TN_R_package("package:TruncatedNormal"); 
    Rcpp::Function f = TN_R_package["rtmvnorm"];

    Rcpp::NumericVector R_mu = Rcpp::wrap(mu);
    Rcpp::NumericMatrix R_sigma = Rcpp::wrap(sigma);
    Rcpp::NumericVector R_lb = Rcpp::wrap(lb);
    Rcpp::NumericVector R_ub = Rcpp::wrap(ub);
    // Rcpp::Rcout<<"Start rtmvnorm"<<std::endl;
    // Rcpp::Rcout<<R_lb<<std::endl;
    Rcpp::NumericVector res = f(Rcpp::_["n"]=1, Rcpp::_["mu"]=R_mu,
                                   Rcpp::_["sigma"]=R_sigma, 
                                   Rcpp::_["lb"]=R_lb,
                                   Rcpp::_["ub"]=R_ub);         
    // Rcpp::Rcout<<"Start rtmvnorm and get:"<<std::endl;
    arma::vec res_arma = castNumericVectorToArmaVec(res);
    // Rcpp::Rcout<<res_arma<<std::endl;
    return res_arma;
}

// [[Rcpp::export]]
double rcpp_pmvnorm(const arma::vec mu, const arma::mat sigma, 
                            const arma::vec lb, const arma::vec ub, int B){
    // calling ptmvnorm()
    Rcpp::Environment TN_R_package("package:FBART"); 
    Rcpp::Function f = TN_R_package["pmvnorm_try"];

    Rcpp::NumericVector R_mu = Rcpp::wrap(mu);
    Rcpp::NumericMatrix R_sigma = Rcpp::wrap(sigma);
    Rcpp::NumericVector R_lb = Rcpp::wrap(lb);
    Rcpp::NumericVector R_ub = Rcpp::wrap(ub);
    // Rcpp::Rcout<<"Start pmvnorm"<<std::endl;
    // Rcpp::Rcout<<R_lb<<std::endl;
    SEXP res = f(Rcpp::_["mu"]=R_mu,
                  Rcpp::_["sigma"]=R_sigma, 
                  Rcpp::_["lb"]=R_lb,
                  Rcpp::_["ub"]=R_ub,
                  Rcpp::_["B"]=B);
    // Rcpp::Rcout<<"End pmvnorm and get"<<std::endl;
    double res_double = Rcpp::as<double>(res);
    // Rcpp::Rcout<<res_double<<std::endl;
    return res_double;
}

// pmvnorm(rep(1,3),diag(3),rep(0,3),rep(Inf,3))  
// rcpp_pmvnorm(rep(1,3),diag(3),rep(0,3),rep(Inf,3))

// set.seed(1)
// rcpp_rtmvnorm(rep(1,3),diag(3),rep(0,3),rep(Inf,3))
// set.seed(1)
// rtmvnorm(1,rep(1,3),diag(3),rep(0,3),rep(Inf,3))