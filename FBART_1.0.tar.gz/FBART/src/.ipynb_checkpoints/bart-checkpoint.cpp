#include "tree.h"
// Hyperparameters
using namespace Rcpp;
using namespace arma;

void IterateGibbs(std::vector<Node*>& forest, std::vector<arma::vec>& Y_hat,
                     Hypers& hypers, const arma::mat& X, const std::vector<arma::vec>& Y,
                     const Opts& opts);
Node* draw_prior(Node* tree, const arma::mat& X, const std::vector<arma::vec>& Y, Hypers& hypers);
void birth_death(Node* tree, const arma::mat& X, const std::vector<arma::vec>& Y, Hypers& hypers);
void node_birth(Node* tree, const arma::mat& X, const std::vector<arma::vec>& Y, Hypers& hypers);
void node_death(Node* tree, const arma::mat& X, const std::vector<arma::vec>& Y, Hypers& hypers);
void TreeBackfit(std::vector<Node*>& forest, std::vector<arma::vec>& Y_hat, Hypers& hypers, 
                  const arma::mat& X, const std::vector<arma::vec>& Y,const Opts& opts) ;
void perturb_decision_rule(Node* tree,const arma::mat& X,const std::vector<arma::vec>& Y,Hypers& hypers);
// --------------// --------------// --------------
// Proposal prob

double growth_prior(int leaf_depth, const Hypers& hypers) {
  return hypers.gamma * pow(1.0 + leaf_depth, -hypers.alpha);
}
double probability_node_birth(Node* tree) {
  return tree->is_leaf ? 1.0 : 0.5;
}
// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Function Body

Rcpp::List do_functional_bart(const arma::mat& X,
                        const std::vector<arma::vec>& Y,
                        const arma::mat& X_test,
                        Hypers& hypers,
                        const Opts& opts) {

  std::vector<Node*> forest = init_forest(hypers);
  // In the original BART code, the start value is zero, so no predict needed.
  std::vector<arma::vec> Y_hat = predict(forest, X, hypers);
    
  // Do burn_in
  for(int i = 0; i < opts.num_burn; i++) {

    IterateGibbs(forest, Y_hat, hypers, X, Y, opts);

    if((i+1) % opts.num_print == 0) {
      Rcout << "Finishing warmup " << i + 1
            // << " Number of trees = " << hypers.num_tree
            << "\n"
        ;
    }
  }

  // Make arguments to return
  std::vector<std::vector<arma::vec>> Y_hat_train(opts.num_save);
  std::vector<std::vector<arma::vec>> Y_hat_test(opts.num_save);
  vec sigma = zeros<vec>(opts.num_save);

  // Do save iterations
  for(int i = 0; i < opts.num_save; i++) {
    for(int b = 0; b < opts.num_thin; b++) {
        IterateGibbs(forest, Y_hat, hypers, X, Y, opts);
    }

    // Save stuff
    Y_hat_train[i] = Y_hat;
    Y_hat_test[i] = predict_test(forest, X_test, hypers);
    sigma(i) = hypers.sigma;

    if((i + 1) % opts.num_print == 0) {
      Rcout << "Finishing save " << i + 1 << "\n";
    }

  }
    
  Rcpp::List out;
  Rcpp::List Y_hat_train_R(X.n_rows);
  Rcpp::List Y_hat_test_R(X_test.n_rows);
  arma::mat Y_hat_i;
  for (int i = 0; i < X.n_rows; ++i) {
      Y_hat_i = zeros(Y_hat_train[0][i].size(), opts.num_save);
      for (int j = 0; j < opts.num_save; ++j) {
        Y_hat_i.col(j) = Y_hat_train[j][i];
      }
      Y_hat_train_R[i] = Y_hat_i;
  }
  for (int i = 0; i < X_test.n_rows; ++i) {
      Y_hat_i = zeros(Y_hat_test[0][i].size(), opts.num_save);
      for (int j = 0; j < opts.num_save; ++j) {
        Y_hat_i.col(j) = Y_hat_test[j][i];
      }
      Y_hat_test_R[i] = Y_hat_i;
  }
  out["y_hat_train"] = Y_hat_train_R;
  out["y_hat_test"] = Y_hat_test_R;
  out["sigma"] = sigma;
  out["mu1"] = sigma;  
  
  return out;

}

void IterateGibbs(std::vector<Node*>& forest, std::vector<arma::vec>& Y_hat,
                     Hypers& hypers, const arma::mat& X, const std::vector<arma::vec>& Y,
                     const Opts& opts) {


  // Rcout << "Backfitting trees";
  TreeBackfit(forest, Y_hat, hypers, X, Y, opts);

  std::vector<arma::vec> res = Y - Y_hat;

  // Rcout << "Doing other updates";
  hypers.UpdateSigma(res);

//   Rcpp::checkUserInterrupt();
}

void TreeBackfit(std::vector<Node*>& forest, std::vector<arma::vec>& Y_hat, Hypers& hypers, 
                  const arma::mat& X, const std::vector<arma::vec>& Y,const Opts& opts) {

  double MH_BD = 0.7;
  double MH_PRIOR = 0.4;

  int num_tree = hypers.num_tree;
  for(int t = 0; t < num_tree; t++) {
    // Rcout << "Getting backfit quantities\n";
    std::vector<arma::vec> Y_star = Y_hat - predict(forest[t], X, hypers);
    std::vector<arma::vec> res = Y - Y_star;
    // Rcout << "Finish prediction\n";
    if(unif_rand() < MH_PRIOR) {
      // Rcout << "Prior step\n";
      forest[t] = draw_prior(forest[t], X, res, hypers);
    }
    if(forest[t]->is_leaf || unif_rand() < MH_BD) {
      // Rcout << "BD step";
        birth_death(forest[t], X, res, hypers);
      // Rcout << "Done";
    }
    else {
      // Rcout << "Change step";
      perturb_decision_rule(forest[t], X, res, hypers);
      // Rcout << "Done";
    }
    forest[t]->UpdateMu(res, X, hypers);
    Y_hat = Y_star + predict(forest[t], X, hypers);
  }
}


// // ======================// ======================// ======================// ======================
// // ======================// ======================// ======================// ======================
// // Proposals

//----------------//----------------//----------------
Node* draw_prior(Node* tree, const arma::mat& X, const std::vector<arma::vec>& Y, Hypers& hypers) {
  
  // Rcout<< "Compute loglik before\n";
  Node* tree_0 = tree;
  double loglik_before = LogLT(tree_0, Y, X, hypers);
  
  // Rcout<< "Make new tree and compute loglik after\n";
  Node* tree_1 = new Node;
  // Rcout<< "Make a root tree\n";
  tree_1->Root(hypers);
  // Rcout<< "Grow w.r.t. prior till stop\n";
  tree_1->GenBelow(hypers);
  double loglik_after = LogLT(tree_1, Y, X, hypers);
  
  // Rcout<< "Do MH\n";
  if(log(unif_rand()) < loglik_after - loglik_before) {
    delete tree_0;
    tree = tree_1;
  }
  else {
    delete tree_1;
  }
  return tree;
}

//----------------//----------------//----------------
// Birth and death
void birth_death(Node* tree, const arma::mat& X, const std::vector<arma::vec>& Y, Hypers& hypers) {


  double p_birth = probability_node_birth(tree);

  if(unif_rand() < p_birth) {
    node_birth(tree, X, Y, hypers);
  }
  else {
    node_death(tree, X, Y, hypers);
  }
}

void node_birth(Node* tree, const arma::mat& X, const std::vector<arma::vec>& Y, Hypers& hypers) {

  // Rcout << "Sample leaf";
  double leaf_probability = 0.0;
  Node* leaf = birth_node(tree, &leaf_probability);

  // Rcout << "Compute prior";
  int leaf_depth = depth(leaf);
  double leaf_prior = growth_prior(leaf_depth, hypers);

  // Get likelihood of current state
  // Rcout << "Current likelihood";
  double ll_before = LogLT(tree, Y, X, hypers);
  ll_before += log(1.0 - leaf_prior);

  // Get transition probability
  // Rcout << "Transistion";
  double p_forward = log(probability_node_birth(tree) * leaf_probability);

  // Birth new leaves
  // Rcout << "Birth";
  leaf->BirthLeaves(hypers);

  // Get likelihood after
  // Rcout << "New Likelihood";
  double ll_after = LogLT(tree, Y, X, hypers);
  ll_after += log(leaf_prior) +
    log(1.0 - growth_prior(leaf_depth + 1, hypers)) +
    log(1.0 - growth_prior(leaf_depth + 1, hypers));

  // Get Probability of reverse transition
  // Rcout << "Reverse\n";
  std::vector<Node*> ngb = not_grand_branches(tree);
  double p_not_grand = 1.0 / ((double)(ngb.size()));
  double p_backward = log((1.0 - probability_node_birth(tree)) * p_not_grand);

  // Do MH
  double log_trans_prob = ll_after + p_backward - ll_before - p_forward;
  if(log(unif_rand()) > log_trans_prob) {
    leaf->DeleteLeaves();
    leaf->var = 0;
  }
  else {
    // Rcout << "Accept!";
  }
}

void node_death(Node* tree, const arma::mat& X, const std::vector<arma::vec>& Y, Hypers& hypers) {

  // Select branch to kill Children
  double p_not_grand = 0.0;
  Node* branch = death_node(tree, &p_not_grand);

  // Compute before likelihood
  int leaf_depth = depth(branch->left);
  double leaf_prob = growth_prior(leaf_depth - 1, hypers);
  double left_prior = growth_prior(leaf_depth, hypers);
  double right_prior = growth_prior(leaf_depth, hypers);
  double ll_before = LogLT(tree, Y, X, hypers) +
    log(1.0 - left_prior) + log(1.0 - right_prior) + log(leaf_prob);

  // Compute forward transition prob
  double p_forward = log(p_not_grand * (1.0 - probability_node_birth(tree)));

  // Save old leafs, do not delete (they are dangling, need to be handled by the end)
  Node* left = branch->left;
  Node* right = branch->right;
  branch->left = branch;
  branch->right = branch;
  branch->is_leaf = true;

  // Compute likelihood after
  double ll_after = LogLT(tree, Y, X, hypers) + log(1.0 - leaf_prob);

  // Compute backwards transition
  std::vector<Node*> leafs = leaves(tree);
  double p_backwards = log(1.0 / ((double)(leafs.size())) * probability_node_birth(tree));

  // Do MH and fix dangles
  double log_trans_prob = ll_after + p_backwards - ll_before - p_forward;
  if(log(unif_rand()) > log_trans_prob) {
    branch->left = left;
    branch->right = right;
    branch->is_leaf = false;
  }
  else {
    delete left;
    delete right;
  }
}

void perturb_decision_rule(Node* tree,
                           const arma::mat& X,
                           const std::vector<arma::vec>& Y,
                           Hypers& hypers) {
  
  // Randomly choose a branch; if no branches, we automatically reject
  std::vector<Node*> bbranches = branches(tree);
  if(bbranches.size() == 0)
    return;
  
  // Select the branch
  Node* branch = rand(bbranches);
  
  // Calculuate tree likelihood before proposal
  double ll_before = LogLT(tree, Y, X, hypers);
  
  // Calculate product of all 1/(B - A) here
  double cutpoint_likelihood = calc_cutpoint_likelihood(tree);
  
  // Calculate backward transition density
  std::vector<double> lims = get_perturb_limits(branch);
  double backward_trans = 1.0/(lims[1] - lims[0]);
  
  // save old split
  int old_feature = branch->var;
  double old_value = branch->val;
  double old_lower = branch->lower;
  double old_upper = branch->upper;
  
  // Modify the branch
  branch->var = hypers.SampleVar();
  // branch->GetLimits();
  lims = get_perturb_limits(branch);
  branch->val = lims[0] + (lims[1] - lims[0]) * unif_rand();
  get_limits_below(branch);
  
  // Calculate likelihood after proposal
  double ll_after = LogLT(tree, Y, X, hypers);
  
  // Calculate product of all 1/(B-A)
  double cutpoint_likelihood_after = calc_cutpoint_likelihood(tree);
  
  // Calculate forward transition density
  double forward_trans = 1.0/(lims[1] - lims[0]);
  
  // Do MH
  double log_trans_prob =
    ll_after + log(cutpoint_likelihood_after) + log(backward_trans)
    - ll_before - log(cutpoint_likelihood) - log(forward_trans);
  
  if(log(unif_rand()) > log_trans_prob) {
    branch->var = old_feature;
    branch->val = old_value;
    branch->lower = old_lower;
    branch->upper = old_upper;
    get_limits_below(branch);
  }
}




// ======================// ======================// ======================// ======================
// ======================// ======================// ======================// ======================
// Export function

// // [[Rcpp::export]]
// Rcpp::List Do_Functional_Bart(const Rcpp::NumericMatrix X, const Rcpp::NumericMatrix Y, const Rcpp::NumericMatrix X_test) {

// Rscript -e "library(FBART); Do_Functional_Bart(diag(3),diag(3),diag(3)) "

// Process R inputs for do_functional_bart
// [[Rcpp::export]]
List Do_Functional_Bart(const arma::mat& X, Rcpp::List Y_R, const arma::mat& X_test,
              double alpha, double gamma, double lambda, double nu, 
              arma::vec mu_mu, arma::mat V_mu, arma::mat V_mu_inv,
              int num_tree, int p, Rcpp::IntegerVector m_list, int J,
              Rcpp::List Phi_list, Rcpp::List Phi_list_test,
              arma::mat D, arma::mat D_inv, 
              bool is_constrained, arma::vec lb, arma::vec ub, double prior_trunc_prob, int B,
              double sigma, double sigma_hat,
              int num_burn, int num_thin, int num_save, int num_print) {
  Rcout << "Start init opts\n";
  Opts opts = InitOpts(num_burn, num_thin, num_save, num_print);
  Rcout << "Start init hypers\n";
  Hypers hypers = InitHypers(alpha, gamma, lambda, nu, mu_mu, V_mu, V_mu_inv, 
                            num_tree, p, m_list, J, Phi_list, Phi_list_test, 
                            D, D_inv, is_constrained, lb, ub, 
                            prior_trunc_prob, B, sigma, sigma_hat);
  Rcout << "Doing functional bart\n";
  std::vector<arma::vec> Y(Y_R.size());
  for(int i = 0; i<Y_R.size(); i++){
    Rcpp::NumericVector Y_R_i = Y_R[i];
    Y[i] = castNumericVectorToArmaVec(Y_R_i);
  }
  return do_functional_bart(X, Y, X_test, hypers, opts);
}

